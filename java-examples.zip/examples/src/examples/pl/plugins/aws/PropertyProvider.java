package examples.pl.plugins.aws;

import gw.api.system.PLLoggerCategory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Holder/loader for multiple overlaid property files.
 * Use builder for construction.
 */
public class PropertyProvider {

  /**
   * Empty provider for null lookups
   */
  public static final PropertyProvider EMPTY_PROVIDER = builder().build();

  private final Map<String, String> _properties;

  private PropertyProvider(Map<String, String> properties) {
    _properties = properties;
  }

  /**
   * Returns value for key or null if not present.
   *
   * @param key Key for the value being returned
   * @return Returns value for key or null if not present
   */
  public String lookup(String key) {
    return _properties.get(key);
  }

  /**
   * Creates a builder for a PropertyProvider.
   *
   * @return Returns a new empty builder for a PropertyProvider
   */
  public static Builder builder() {
    return new Builder();
  }

  public static class Builder {

    private List<Properties> _properties = new ArrayList<>();
    private boolean _multi = false;

    private Builder() {
    }

    /**
     * Composes the specified properties, starting with first file added and proceeding
     * in order and returns the populated PropertyProvider.  Duplicate keys overwrite earlier
     * entries in the map, meaning the key-values found in later property sets have precedence.
     *
     * @return PropertyProvider instance for the properties added to this builder
     */
    public PropertyProvider build() {
      Map<String, String> tmp = _properties.isEmpty() ? Collections.emptyMap() : new HashMap<>();
      for(Properties props : _properties) {
        for(String key : props.stringPropertyNames()) {
          if(tmp.put(key, props.getProperty(key)) != null) {
            PLLoggerCategory.CONFIG.trace("Replaced value for key {}", key);
          }
        }
      }
      return new PropertyProvider(tmp);
    }

    /**
     * Sets the flag allowing loading multiple property streams.  Otherwise an exception
     * will be thrown if more than one stream is loaded.
     *
     * @return this builder
     */
    public Builder multi() {
      _multi = true;
      return this;
    }

    /**
     * Load from this property stream, assuming bytes are UTF8.
     * Consumes entire stream and closes it.
     *
     * @param is UTF8 byte stream in property file format
     * @return this builder
     */
    public Builder load(InputStream is) {
      load(new InputStreamReader(is, StandardCharsets.UTF_8));
      return this;
    }

    /**
     * Load from this property stream, assuming bytes are the specified charset.
     * Consumes entire stream and closes it.
     *
     * @param is byte stream in property file format
     * @param cs charset for stream
     * @return this builder
     */
    public Builder load(InputStream is, Charset cs) {
      load(new InputStreamReader(is, cs));
      return this;
    }

    /**
     * Load properties from this reader, consuming all content and closing it.
     *
     * @param reader character reader in property file format
     * @return this builder
     */
    public Builder load(Reader reader) {
      if(_multi || _properties.isEmpty()) {
        _properties.add(loadProperties(reader));
      } else {
        throw new IllegalArgumentException("Attempt to load multiple property sets when a single set was expected.");
      }
      return this;
    }

    private Properties loadProperties(Reader reader) {
      try (BufferedReader bufferedReader = new BufferedReader(reader)) {
        Properties parsed = new Properties();
        parsed.load(bufferedReader);
        return parsed;
      } catch (IOException ex) {
        throw new UncheckedIOException("Unable to load properties", ex);
      }
    }
  }

}
