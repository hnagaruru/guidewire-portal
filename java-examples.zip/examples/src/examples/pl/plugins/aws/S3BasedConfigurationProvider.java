package examples.pl.plugins.aws;

import gw.api.system.PLLoggerCategory;
import gw.plugin.extconfig.ExternalConfigurationProviderPlugin;
import org.slf4j.Logger;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Object;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;

/**
 * AWS S3 based implementation of the ExternalConfigurationProviderPlugin
 * <br><br>
 * Install as a plugin via ExternalConfigurationProviderPlugin.gwp
 * <br><br>
 * Uses system parameter "gw.config.external.property.s3.object" in the form
 * "&lt;bucket&gt;/&lt;key to object&gt;", e.g. "myBucket/prod/external.properties" to
 * find and load a standard property file.
 * <br><br>
 * Property values are stored as key-value pairs and are used by the existing
 * ExternalConfiguration substitution system.
 * <br><br>
 * The property values can be accessed from Gosu code via the ExternalConfiguration lookup API
 * <pre>
 *   uses gw.external.configuration.SubstitutionProperties
 *   var propertyAPI = new SubstitutionProperties()
 *   ...
 *   propertyAPI.lookupValue("mynamespace", "mykey")
 * </pre>
 */
public class S3BasedConfigurationProvider implements ExternalConfigurationProviderPlugin {

  // Value is of the form <S3 bucket name>/path/to/file
  private static final String S3_OBJECT_PATH_NAME = "gw.config.external.property.s3.object";
  private static final Logger LOGGER = PLLoggerCategory.CONFIG;

  private final PropertyProvider _provider;

  public S3BasedConfigurationProvider() {
    _provider = loadProperties();
  }

  /**
   * Load properties from the configured S3 bucket/object.
   *
   * @return Fully populated property provider for this plugin
   */
  private PropertyProvider loadProperties() {
    String s3Path = System.getProperty(S3_OBJECT_PATH_NAME);
    if (s3Path == null || s3Path.isEmpty()) {
      LOGGER.info("No external properties S3 object path is provided. All configuration substitutions without default values will be left unchanged.");
      return PropertyProvider.EMPTY_PROVIDER;
    }

    int indexOfSlash = s3Path.indexOf('/');
    if (indexOfSlash == -1) {
      LOGGER.warn("The S3 object path is in an incorrect format; it should be <bucket>/<key>. All configuration substitutions without default values will be left unchanged.");
      return PropertyProvider.EMPTY_PROVIDER;
    }

    PropertyProvider.Builder builder = PropertyProvider.builder();

    LOGGER.info("Using S3 object path to load external properties: {}", s3Path);
    String s3Bucket = s3Path.substring(0, indexOfSlash);
    String s3Key = s3Path.substring(indexOfSlash + 1);

    // Requires AWS credentials and other configuration be supplied or available as per javadoc, e.g.
    // AWS_ACCESS_KEY_ID and AWS_SECRET_KEY, java system properties, credentials profile, etc.
    // See also Amazon AWS API docs for further details on environment configuration
    //  https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-envvars.html
    S3Client s3Client = S3Client.builder().build();
    GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(s3Bucket).key(s3Key).build();
    try (InputStream s3InputStream = s3Client.getObject(getObjectRequest)) {
      builder.load(s3InputStream);
    } catch (IOException e) {
      LOGGER.error("IO Exception while reading external properties S3 object.", e);
      throw new UncheckedIOException(e);
    }
    return builder.build();
  }

  @Override
  public String lookupValue(String namespace, String key) {
    String fullyQualifiedKey = (namespace == null || namespace.isEmpty()) ? key : namespace + "." + key;
    return _provider.lookup(fullyQualifiedKey);
  }

}
