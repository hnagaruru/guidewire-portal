package examples.pl.plugins.integration.inbound.custom;

import com.google.common.base.MoreObjects;
import gw.api.integration.inbound.Factory;
import gw.api.integration.inbound.WorkAgent;
import gw.api.integration.inbound.work.Handler;
import gw.api.integration.inbound.work.Inbound;
import gw.api.integration.inbound.work.WorkContext;
import gw.api.integration.inbound.work.WorkData;
import gw.api.integration.inbound.work.WorkDataSet;
import gw.api.integration.inbound.work.WorkSetProcessor;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.osgi.service.component.annotations.ConfigurationPolicy.REQUIRE;

@Component( service = CustomInboundIntegration.class, configurationPolicy = REQUIRE )
public class CustomInboundIntegration implements WorkAgent, Factory, Inbound, WorkSetProcessor {
  private static Logger log = LoggerFactory.getLogger( CustomInboundIntegration.class.getSimpleName() );

  private Map<String, Object> _settings;

  private Random _random = new Random();

  /**
   * Lifecycle method for initializtion
   *
   * @param properties configuration properties
   *                   - called before start()
   */
  @Override
  public void setup( final Map<String, Object> properties ) {
    _settings = new HashMap<>( properties );
    log.info( "setup: {}", properties );
  }

  /**
   * Inject the configured plugin data handler
   * This will be called before start()
   *
   * @param handler
   */
  @Override
  public void setHandler( final Handler handler ) {
    log.info( "setHandler: {}", handler );
  }

  /**
   * Lifecycle method for teardown
   * - called after stop()
   */
  @Override
  public void teardown() {
    log.info( "teardown" );
  }

  /**
   * Start work listener
   */
  @Override
  public void start() {
    log.info( "start" );
  }

  /**
   * Stop work listener
   */
  @Override
  public void stop() {
    log.info( "stop" );
  }

  /**
   * Whether or not this agent is transactional
   * If it is transactional, it is expected that
   * factory().createWorkUnit() will return an instance of
   * TransactionalWork
   */
  @Override
  public boolean transactional() {
    return false;
  }

  /**
   * Factory method for retrieving the factory for WorkUnit
   * processors
   */
  @Override
  public Factory factory() {
    log.info( "factory" );
    return this;
  }

  @Override
  public Inbound getInbound() {
    return this;
  }

  @Override
  public WorkSetProcessor createWorkProcessor() {
    return this;
  }

  @Override
  public WorkDataSet findWork() {
    int contextId = _random.nextInt( 10000 ) + _random.nextInt( 10000 );
    int count = _random.nextInt( 5 );
    return generateSampleData( contextId, count );
  }

  public CustomWorkDataSet generateSampleData( int contextId, int sampleSize ) {
    CustomWorkContext context = new CustomWorkContext( contextId );
    List<Integer> _workData = new ArrayList<>();
    int start = _random.nextInt( 1024 ) + 1024;
    for ( int i = 0; i < sampleSize; i++ ) {
      _workData.add( start + i );
    }
    return new CustomWorkDataSet( context, _workData );
  }

  @Override
  public void process( final WorkContext context, final WorkData data ) {
    log.info( "process(context={}, data={})", context, data );
  }

  private static class CustomWorkContext implements WorkContext {
    private int _id;

    CustomWorkContext( int id ) {
      _id = id;
    }

    public int getId() {
      return _id;
    }

    @Override
    public String toString() {
      return MoreObjects.toStringHelper( this )
          .add( "id", _id )
          .toString();
    }
  }

  private static class CustomWorkDataSet implements WorkDataSet {

    private final CustomWorkContext _context;
    private final List<Integer> _workData;
    private final Iterator<Integer> _iterator;


    CustomWorkDataSet( CustomWorkContext context, Collection<Integer> dataset ) {
      _context = context;
      _workData = new CopyOnWriteArrayList<>( dataset );
      _iterator = _workData.iterator();
    }

    /**
     * The current poll will continue to process data until this returns false
     */
    @Override
    public boolean hasNext() {
      return _iterator.hasNext();
    }

    /**
     * Return data item in this group
     * returning null signifies end
     */
    @Override
    public WorkData getData() {
      return new CustomWorkData( _iterator.next() );
    }

    /**
     * Return data set context
     */
    @Override
    public WorkContext getContext() {
      return _context;
    }

    /**
     * Close data resources
     */
    @Override
    public void close() {
      _workData.clear();
    }

    private class CustomWorkData implements WorkData {
      private final Integer _data;

      public CustomWorkData( final Integer data ) {
        _data = data;
      }

      public Integer getData() {
        return _data;
      }

      @Override
      public String toString() {
        return MoreObjects.toStringHelper( this )
            .add( "data", _data )
            .toString();
      }
    }
  }

}
