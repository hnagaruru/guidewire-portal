package examples.pl.plugins.integration.inbound.fileadapter;

import gw.plugin.integration.inbound.InboundIntegrationHandlerPlugin;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(service = SampleLineProcessor.class)
public class SampleLineProcessor implements InboundIntegrationHandlerPlugin {
  private static final Logger log = LoggerFactory.getLogger(SampleLineProcessor.class);

  @Activate
  public void init() {
    log.info("SampleLineProcessor init()");
  }

  @Override
  public void process(final Object line) {
    log.info("{}.processLine: {}", SampleLineProcessor.class.getName(), line);
  }

}
