PLEASE DO NOT EDIT ANY OF THESE FILES BY HAND.

Run the regen-phone-metadata target after you have reconfigured the PhoneNumberMetaData.xml file.