# Do not modify any files in global_variables to change a theme. Unless you want the changes to be reflected in ALL themes. #

# Instead #
* Read `sass/_SASS_Directions/`
* Then override the global variables in these files in a theme file.